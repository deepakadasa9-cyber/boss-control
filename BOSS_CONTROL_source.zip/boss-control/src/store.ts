import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase } from './supabase';
export type Entry = { id:string; kind:'earning'|'expense'; amount:number; date:string; time:string; category:string; platform?:string; orders?:number; note?:string };
export type Goal = { id:string; name:string; target:number; saved:number };
export type Task = { id:string; title:string; department:string; due:string; priority:string; done:boolean };
export type Data = { target:number; entries:Entry[]; goals:Goal[]; tasks:Task[] };
const KEY='boss-control-v1';
export const emptyData:Data={target:1000,entries:[],goals:[],tasks:[]};
export async function loadData():Promise<Data>{const raw=await AsyncStorage.getItem(KEY);if(!raw)return emptyData;try{return {...emptyData,...JSON.parse(raw)}}catch{return emptyData}}
export async function saveData(data:Data){await AsyncStorage.setItem(KEY,JSON.stringify(data));if(supabase){const {data:{user}}=await supabase.auth.getUser();if(user){await supabase.from('user_data').upsert({user_id:user.id,payload:data,updated_at:new Date().toISOString()},{onConflict:'user_id'});}}}
export const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
export const money=(n:number)=>'₹'+Math.round(n).toLocaleString('en-IN');
