# BOSS CONTROL – personal Android app source

This is an Expo React Native starter project with a working personal ledger, daily target progress, expenses, savings goals, tasks, history, and reports. It starts in phone-local storage mode. Supabase cloud sync and the AI backend are optional and require your own project credentials.

## Run on Android
1. Install Node.js LTS and Git on a computer.
2. Extract this folder and open a terminal inside it.
3. Run `npm install`.
4. Run `npx expo start` and scan the QR code with Expo Go, or run `npx expo run:android` with Android Studio set up.

## Enable private cloud backup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in its SQL Editor.
3. Copy `.env.example` to `.env` and fill in the project URL and anon key.
4. Configure Supabase Auth (email/password) and implement the sign-in screen before using cloud sync in production. The SQL Row Level Security policy restricts each row to its owner.

## Enable AI
Deploy `supabase/functions/ai-manager` using the Supabase CLI and set `OPENAI_API_KEY` as a Supabase Edge Function secret. The key must never be placed in the Expo app or `.env` file. The AI endpoint verifies the user's Supabase session.

## Important limitations of this first source build
- No sample transactions are inserted. Reports show only entries you add.
- Local data is stored on this phone. Cloud sync requires Supabase setup and authentication.
- The current UI is a functional first version, not a production-audited banking product. Add and test authentication, backup/restore, error handling, and device security before storing sensitive financial records.
- AI department cards describe the planned roles; the live AI chat workflow still needs to be connected to the deployed Edge Function.
- Android APK/AAB builds require an Android build environment or an Expo EAS account and your app signing configuration.
