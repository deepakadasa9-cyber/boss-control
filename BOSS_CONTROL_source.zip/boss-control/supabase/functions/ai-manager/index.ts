import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
serve(async (req) => {
 if(req.method!=='POST')return new Response('Method not allowed',{status:405});
 const auth=req.headers.get('Authorization');if(!auth)return new Response('Unauthorized',{status:401});
 const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!,{global:{headers:{Authorization:auth}}});
 const {data:{user}}=await supabase.auth.getUser();if(!user)return new Response('Unauthorized',{status:401});
 const {prompt,financialSummary}=await req.json();const apiKey=Deno.env.get('OPENAI_API_KEY');
 if(!apiKey)return new Response(JSON.stringify({error:'AI is not configured yet.'}),{status:503,headers:{'Content-Type':'application/json'}});
 const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4.1-mini',input:`You are an honest personal assistant. Never invent financial data. Clearly separate facts from estimates. Give practical, simple advice.\nUser request: ${String(prompt).slice(0,3000)}\nFinancial summary supplied by app: ${JSON.stringify(financialSummary).slice(0,4000)}`})});
 return new Response(JSON.stringify(await response.json()),{status:response.status,headers:{'Content-Type':'application/json'}});
});
